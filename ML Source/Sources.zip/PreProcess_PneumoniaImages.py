# -*- coding: utf-8 -*-
"""
Created on Fri Jul 24 16:54:11 2020

@author: ragavant
"""
# importing required libraries
import pandas as pd
import matplotlib.pyplot as plt

%matplotlib inline
from matplotlib import patches
from os import listdir
# read the csv file using read_csv function of pandas
train = pd.read_csv('Annatote.csv')
train.head()

# reading single image using imread function of matplotlib
#image = plt.imread('JPEGImages/BloodImage_00000.jpg')
#plt.imshow(image)


# Number of unique training images
train['ImageName'].nunique()

# Number of classes
train['AbNormalType'].value_counts()

TrainImages = listdir("train_images")

   
    
for Imagefile in TrainImages:
    
    fig = plt.figure()

    #add axes to the image
    ax = fig.add_axes([0,0,1,1])

    # read and plot the image
    image = plt.imread('train_images/'+Imagefile)
    plt.imshow(image)

    # iterating over the image for different objects
    for _,row in train[train.ImageName == Imagefile ].iterrows():
        print(row.ImageName)
        xmin = row.xmin
        xmax = row.xmax
        ymin = row.ymin
        ymax = row.ymax
    
        width = xmax - xmin
        height = ymax - ymin
    
       # assign different color to different classes of objects
        if row.AbNormalType == 'Pneumonia':
            edgecolor = 'r'
            ax.annotate('Pneumonia', xy=(xmax-40,ymin+20))
       # elif row.Celltype == 'WBC':
       #     edgecolor = 'b'
       #     ax.annotate('WBC', xy=(xmax-40,ymin+20))
       # elif row.Celltype == 'Platelets':
       #     edgecolor = 'g'
       #     ax.annotate('Platelets', xy=(xmax-40,ymin+20))
            
        # add bounding boxes to the image
        rect = patches.Rectangle((xmin,ymin), width, height, edgecolor = edgecolor, facecolor = 'none')
        
        ax.add_patch(rect)
        
        plt.savefig( 'Annatote_Images/'+Imagefile);
  
    

data = pd.DataFrame()
data['format'] = train['ImageName']

# as the images are in train_images folder, add train_images before the image name
for i in range(data.shape[0]):
    data['format'][i] = 'train_images/' + data['format'][i]

# add xmin, ymin, xmax, ymax and class as per the format required
for i in range(data.shape[0]):
    data['format'][i] = data['format'][i] + ',' + str(train['xmin'][i]) + ',' + str(train['ymin'][i]) + ',' + str(train['xmax'][i]) + ',' + str(train['ymax'][i]) + ',' + train['AbNormalType'][i]

data.to_csv('annotate.txt', header=None, index=None, sep=' ')